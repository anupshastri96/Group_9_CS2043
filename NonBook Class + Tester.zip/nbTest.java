public class nbTest {

	public static void main(String[] args) {
		NonBook nb1 = new NonBook("Movie", "George Lucas", "Sci-fi", 1, 5, "Star Wars", 5, 1977, "LucasFilm", null);
	nb1.getDetails();
	NonBook nb2 = new NonBook("Movie", "George Lucas", "Adventure", 1, 5, "Indiana Jones", 5, 1981, "LucasFilm", null);
	nb2.getDetails();
	nb1.setTitle("A New Hope");
	nb1.getDetails();
	}

}
